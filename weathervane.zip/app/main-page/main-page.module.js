'use strict';

angular
  .module('mainPage', [
    'geocoding',
    'keyService',
    'forecastRequest'
  ]);
