'use strict';

angular
  .module('mainPage')
  .component('mainPage', {
    templateUrl: './main-page/main-page.template.html',
    controller: ['keyService',
                 'geocodingService',
                 'forecastRequestService',
      function mainPageController(keyService,
                                  geocodingService,
                                  forecastRequestService) {
        var _this = this;

        this.locationInput = '';

        this.getLocationConditions = function getLoactionConditions() {
          geocodingService.getLatLngByAddress(_this.locationInput);


          /*
          keyService.getKey("Open Weather Map").then(function(key){
            forecastRequestService.requestByLatLng(22, 164, key);
          });
          */

        }
      }
    ]
  });
