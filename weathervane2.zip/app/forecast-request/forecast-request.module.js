'use strict';

angular.module('forecastRequest', [
    'keyService'
]);
