'use strict';

angular.module('forecastFormat', []);
