'use strict';

angular.module('wvApp', [
  'ngRoute',
  'mainPage'
]);
