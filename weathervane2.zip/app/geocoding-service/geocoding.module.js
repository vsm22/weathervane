'use strict';

angular.module('geocoding', [
  'keyService'
]);
