'use strict';

angular.module('keyService', []);
